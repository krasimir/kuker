if (typeof window !== 'undefined') {
  window['__kuker__is_here__'] = true;
}
