chrome.devtools.panels.create(
	"Kuker",
	"img/icon16.png",
	"index.html",
	function(panel) {
		
	}
);